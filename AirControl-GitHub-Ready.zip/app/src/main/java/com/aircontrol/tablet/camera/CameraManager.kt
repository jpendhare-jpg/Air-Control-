package com.aircontrol.tablet.camera

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService

/**
 * Owns the CameraX front-facing camera pipeline bound to [GestureControlForegroundService].
 * Operates completely independently of any Activity or Compose preview so camera frame
 * analysis continues when AirControl is in the background and Chrome/YouTube/Gallery is open.
 */
class CameraManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val cameraExecutor: ExecutorService,
    private val onFrameAvailable: (ImageProxy) -> Unit,
    private val onCameraError: (String) -> Unit
) {
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null

    fun startFrontCamera(targetRotation: Int) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetRotation(targetRotation)
                    .build()
                    .also { ia ->
                        ia.setAnalyzer(cameraExecutor) { imageProxy ->
                            onFrameAvailable(imageProxy)
                        }
                    }

                imageAnalysis = analysis
                provider.unbindAll()
                provider.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    analysis
                )
            } catch (e: Exception) {
                onCameraError("Front camera could not be accessed: ${e.localizedMessage}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun updateTargetRotation(rotation: Int) {
        imageAnalysis?.targetRotation = rotation
    }

    fun stopCamera() {
        try {
            cameraProvider?.unbindAll()
        } catch (_: Exception) {}
        imageAnalysis = null
        cameraProvider = null
    }
}
