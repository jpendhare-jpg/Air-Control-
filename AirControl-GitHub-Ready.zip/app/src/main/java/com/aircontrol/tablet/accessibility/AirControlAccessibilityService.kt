package com.aircontrol.tablet.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.max

/**
 * System-wide Android AccessibilityService that dispatches physical screen taps,
 * two-finger vertical scroll strokes, and global navigation actions (GLOBAL_ACTION_RECENTS,
 * GLOBAL_ACTION_HOME, GLOBAL_ACTION_BACK) to whatever application is currently underneath
 * the floating WindowManager overlay cursor (Chrome, YouTube, Gallery, Settings, Files, Games).
 */
class AirControlAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Privacy by design: AirControl does not inspect or log window text or user content.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
            _isConnected.value = false
        }
    }

    /**
     * Dispatches a single system-wide tap at the physical display coordinates (x, y)
     * targeting whatever application window is currently underneath the cursor.
     */
    fun dispatchTap(x: Float, y: Float): Boolean {
        val safeX = max(0f, x)
        val safeY = max(0f, y)
        val clickPath = Path().apply { moveTo(safeX, safeY) }
        val stroke = GestureDescription.StrokeDescription(clickPath, 0L, 48L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    /**
     * Dispatches a smooth vertical swipe stroke at the current cursor position (x, startY)
     * to scroll the application currently underneath the cursor.
     */
    fun dispatchScroll(x: Float, startY: Float, deltaY: Float): Boolean {
        val safeX = max(1f, x)
        val safeStartY = max(1f, startY)
        val endY = (safeStartY - deltaY).coerceIn(40f, 2500f)
        if (kotlin.math.abs(endY - safeStartY) < 8f) return false
        val scrollPath = Path().apply {
            moveTo(safeX, safeStartY)
            lineTo(safeX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(scrollPath, 0L, 120L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    /**
     * Opens Android Recent Apps / Overview screen when Four-Finger gesture is held.
     */
    fun openRecentApps(): Boolean {
        return performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    companion object {
        @Volatile
        var instance: AirControlAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected
    }
}
