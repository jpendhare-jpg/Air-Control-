package com.aircontrol.tablet.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aircontrol.tablet.gesture.GestureSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.airControlDataStore by preferencesDataStore(name = "aircontrol_settings")

data class AirControlPreferences(
    val gestureSettings: GestureSettings = GestureSettings(),
    val cursorSizeScale: Float = 1.0f,
    val cursorOpacity: Float = 0.94f,
    val targetFps: Int = 30,
    val showDeveloperDebugPanel: Boolean = true
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val CURSOR_SPEED = floatPreferencesKey("cursor_speed")
        val SMOOTHING_ALPHA = floatPreferencesKey("smoothing_alpha")
        val PINCH_RATIO = floatPreferencesKey("pinch_ratio")
        val SCROLL_SENSITIVITY = floatPreferencesKey("scroll_sensitivity")
        val VOLUME_SENSITIVITY = floatPreferencesKey("volume_sensitivity")
        val CURSOR_SIZE = floatPreferencesKey("cursor_size")
        val CURSOR_OPACITY = floatPreferencesKey("cursor_opacity")
        val TARGET_FPS = intPreferencesKey("target_fps")
        val MIRROR_CAMERA = booleanPreferencesKey("mirror_camera")
        val SHOW_DEBUG = booleanPreferencesKey("show_debug_panel")
        val ENABLE_CURSOR = booleanPreferencesKey("enable_one_finger_cursor")
        val ENABLE_PINCH = booleanPreferencesKey("enable_pinch_click")
        val ENABLE_PALM = booleanPreferencesKey("enable_open_palm_pause")
        val ENABLE_SCROLL = booleanPreferencesKey("enable_two_finger_scroll")
        val ENABLE_VOLUME = booleanPreferencesKey("enable_three_finger_volume")
        val ENABLE_RECENTS = booleanPreferencesKey("enable_four_finger_recents")
    }

    val settingsFlow: Flow<AirControlPreferences> = context.airControlDataStore.data.map { prefs ->
        AirControlPreferences(
            gestureSettings = GestureSettings(
                cursorSpeed = prefs[Keys.CURSOR_SPEED] ?: 1.35f,
                smoothingAlpha = prefs[Keys.SMOOTHING_ALPHA] ?: 0.28f,
                pinchRatioThreshold = prefs[Keys.PINCH_RATIO] ?: 0.29f,
                scrollSensitivity = prefs[Keys.SCROLL_SENSITIVITY] ?: 1.25f,
                volumeSensitivity = prefs[Keys.VOLUME_SENSITIVITY] ?: 1.15f,
                mirrorFrontCamera = prefs[Keys.MIRROR_CAMERA] ?: true,
                enableOneFingerCursor = prefs[Keys.ENABLE_CURSOR] ?: true,
                enablePinchClick = prefs[Keys.ENABLE_PINCH] ?: true,
                enableOpenPalmPause = prefs[Keys.ENABLE_PALM] ?: true,
                enableTwoFingerScroll = prefs[Keys.ENABLE_SCROLL] ?: true,
                enableThreeFingerVolume = prefs[Keys.ENABLE_VOLUME] ?: true,
                enableFourFingerRecents = prefs[Keys.ENABLE_RECENTS] ?: true
            ),
            cursorSizeScale = prefs[Keys.CURSOR_SIZE] ?: 1.0f,
            cursorOpacity = prefs[Keys.CURSOR_OPACITY] ?: 0.94f,
            targetFps = prefs[Keys.TARGET_FPS] ?: 30,
            showDeveloperDebugPanel = prefs[Keys.SHOW_DEBUG] ?: true
        )
    }

    suspend fun updateCursorSpeed(speed: Float) {
        context.airControlDataStore.edit { it[Keys.CURSOR_SPEED] = speed.coerceIn(0.6f, 2.5f) }
    }

    suspend fun updateSmoothingAlpha(alpha: Float) {
        context.airControlDataStore.edit { it[Keys.SMOOTHING_ALPHA] = alpha.coerceIn(0.10f, 0.80f) }
    }

    suspend fun updatePinchThreshold(threshold: Float) {
        context.airControlDataStore.edit { it[Keys.PINCH_RATIO] = threshold.coerceIn(0.18f, 0.42f) }
    }

    suspend fun updateScrollSensitivity(sensitivity: Float) {
        context.airControlDataStore.edit { it[Keys.SCROLL_SENSITIVITY] = sensitivity.coerceIn(0.5f, 2.5f) }
    }

    suspend fun updateVolumeSensitivity(sensitivity: Float) {
        context.airControlDataStore.edit { it[Keys.VOLUME_SENSITIVITY] = sensitivity.coerceIn(0.5f, 2.5f) }
    }

    suspend fun updateTargetFps(fps: Int) {
        context.airControlDataStore.edit { it[Keys.TARGET_FPS] = fps }
    }

    suspend fun updateMirrorCamera(mirror: Boolean) {
        context.airControlDataStore.edit { it[Keys.MIRROR_CAMERA] = mirror }
    }
}
