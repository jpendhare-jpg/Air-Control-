package com.aircontrol.tablet.camera

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import kotlin.math.max

/**
 * On-device MediaPipe Hand Landmarker processor.
 *
 * Implements the exact coordinate pipeline:
 * CameraX ImageProxy
 *  -> Rotation correction (0°, 90°, 180°, 270° for Portrait & Landscape tablet orientation)
 *  -> Front-camera mirror compensation (postScale(-1f, 1f) so moving the index finger RIGHT
 *     in the real world moves the cursor RIGHT on the physical display)
 *  -> Square IMAGE_DIMENSIONS projection buffer (eliminates landmark_projection_calculator.cc:81 warning)
 *  -> Inverse aspect-ratio unprojection back to [0f..1f] of the oriented camera frame.
 */
data class HandTrackingFrameResult(
    val landmarks: List<NormalizedLandmark>,
    val confidenceScore: Float,
    val cameraWidth: Int,
    val cameraHeight: Int,
    val cameraRotation: Int,
    val isMirrored: Boolean,
    val timestampMs: Long
)

class MediaPipeHandTracker(
    private val context: Context,
    private val onResults: (HandTrackingFrameResult) -> Unit,
    private val onError: (String) -> Unit
) {
    private var handLandmarker: HandLandmarker? = null
    private var lastAnalyzedTimestampMs = 0L
    @Volatile var targetFps: Int = 30

    private var squareProjectionBitmap: Bitmap? = null
    private var squareProjectionCanvas: Canvas? = null
    private val projectionMatrix = Matrix()

    @Volatile private var currentOrientedWidth: Int = 1280
    @Volatile private var currentOrientedHeight: Int = 720
    @Volatile private var currentRotationDegrees: Int = 0
    @Volatile private var currentSquareSize: Int = 1280
    @Volatile private var currentPadX: Float = 0f
    @Volatile private var currentPadY: Float = 0f

    private val imageProcessingOptions: ImageProcessingOptions =
        ImageProcessingOptions.builder()
            .setRotationDegrees(0)
            .build()

    init {
        initializeLandmarker()
    }

    private fun initializeLandmarker() {
        try {
            handLandmarker = buildWithDelegate(Delegate.GPU)
        } catch (_: Exception) {
            try {
                handLandmarker = buildWithDelegate(Delegate.CPU)
            } catch (e: Exception) {
                onError("MediaPipe HandLandmarker initialization failed: ${e.localizedMessage}")
            }
        }
    }

    private fun buildWithDelegate(delegate: Delegate): HandLandmarker {
        val baseOptions = BaseOptions.builder()
            .setDelegate(delegate)
            .setModelAssetPath("hand_landmarker.task")
            .build()

        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(baseOptions)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.45f)
            .setMinHandPresenceConfidence(0.45f)
            .setMinTrackingConfidence(0.45f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ ->
                unprojectAndDeliverResult(result, SystemClock.uptimeMillis())
            }
            .setErrorListener { error ->
                onError(error.message ?: "MediaPipe HandLandmarker error")
            }
            .build()

        return HandLandmarker.createFromOptions(context, options)
    }

    private fun unprojectAndDeliverResult(result: HandLandmarkerResult, timestampMs: Long) {
        val rawHand = result.landmarks().firstOrNull()
        if (rawHand.isNullOrEmpty()) {
            onResults(
                HandTrackingFrameResult(
                    landmarks = emptyList(),
                    confidenceScore = 0f,
                    cameraWidth = currentOrientedWidth,
                    cameraHeight = currentOrientedHeight,
                    cameraRotation = currentRotationDegrees,
                    isMirrored = true,
                    timestampMs = timestampMs
                )
            )
            return
        }

        val sqSize = currentSquareSize.toFloat().coerceAtLeast(1f)
        val padX = currentPadX
        val padY = currentPadY
        val frameW = currentOrientedWidth.toFloat().coerceAtLeast(1f)
        val frameH = currentOrientedHeight.toFloat().coerceAtLeast(1f)

        val unprojected = rawHand.map { lm ->
            val unprojectedX = ((lm.x() * sqSize - padX) / frameW).coerceIn(0f, 1f)
            val unprojectedY = ((lm.y() * sqSize - padY) / frameH).coerceIn(0f, 1f)
            NormalizedLandmark.create(
                unprojectedX,
                unprojectedY,
                lm.z(),
                lm.visibility(),
                lm.presence()
            )
        }

        val score = result.handednesses().firstOrNull()?.firstOrNull()?.score() ?: 0.92f
        onResults(
            HandTrackingFrameResult(
                landmarks = unprojected,
                confidenceScore = score,
                cameraWidth = currentOrientedWidth,
                cameraHeight = currentOrientedHeight,
                cameraRotation = currentRotationDegrees,
                isMirrored = true,
                timestampMs = timestampMs
            )
        )
    }

    fun processImageProxy(imageProxy: ImageProxy) {
        val now = max(lastAnalyzedTimestampMs + 1L, SystemClock.uptimeMillis())
        val minIntervalMs = 1000L / targetFps.coerceIn(10, 60)
        if (now - lastAnalyzedTimestampMs < minIntervalMs) {
            imageProxy.close()
            return
        }
        lastAnalyzedTimestampMs = now

        val rawBitmap = imageProxy.toBitmap()
        val rotationDegrees = imageProxy.imageInfo.rotationDegrees
        val srcWidth = rawBitmap.width
        val srcHeight = rawBitmap.height
        imageProxy.close()

        val isQuarterTurn = rotationDegrees == 90 || rotationDegrees == 270
        val orientedWidth = if (isQuarterTurn) srcHeight else srcWidth
        val orientedHeight = if (isQuarterTurn) srcWidth else srcHeight
        val squareSize = max(orientedWidth, orientedHeight)

        val padX = (squareSize - orientedWidth) / 2f
        val padY = (squareSize - orientedHeight) / 2f

        currentOrientedWidth = orientedWidth
        currentOrientedHeight = orientedHeight
        currentRotationDegrees = rotationDegrees
        currentSquareSize = squareSize
        currentPadX = padX
        currentPadY = padY

        var sqBitmap = squareProjectionBitmap
        if (sqBitmap == null || sqBitmap.width != squareSize || sqBitmap.height != squareSize) {
            sqBitmap = Bitmap.createBitmap(squareSize, squareSize, Bitmap.Config.ARGB_8888)
            squareProjectionBitmap = sqBitmap
            squareProjectionCanvas = Canvas(sqBitmap)
        }

        // 1. Center raw camera frame at origin
        // 2. Rotate by sensor rotationDegrees so Portrait/Landscape is upright
        // 3. Mirror horizontally (-1f, 1f) after rotation so moving hand RIGHT moves X toward 1.0 (RIGHT)
        // 4. Translate into the centered square buffer (squareSize / 2f, squareSize / 2f)
        projectionMatrix.reset()
        projectionMatrix.postTranslate(-srcWidth / 2f, -srcHeight / 2f)
        projectionMatrix.postRotate(rotationDegrees.toFloat())
        projectionMatrix.postScale(-1f, 1f)
        projectionMatrix.postTranslate(squareSize / 2f, squareSize / 2f)

        val canvas = squareProjectionCanvas ?: return
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(rawBitmap, projectionMatrix, null)

        val mpImage = BitmapImageBuilder(sqBitmap).build()
        handLandmarker?.detectAsync(mpImage, imageProcessingOptions, now)
    }

    fun close() {
        handLandmarker?.close()
        handLandmarker = null
        squareProjectionBitmap?.recycle()
        squareProjectionBitmap = null
        squareProjectionCanvas = null
    }
}
