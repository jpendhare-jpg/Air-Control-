package com.aircontrol.tablet.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.aircontrol.tablet.MainActivity
import com.aircontrol.tablet.R
import com.aircontrol.tablet.calibration.CalibrationManager
import com.aircontrol.tablet.camera.CameraManager
import com.aircontrol.tablet.camera.MediaPipeHandTracker
import com.aircontrol.tablet.controller.SystemInteractionController
import com.aircontrol.tablet.gesture.GestureRecognitionEngine
import com.aircontrol.tablet.gesture.GestureSettings
import com.aircontrol.tablet.overlay.SystemCursorOverlay
import com.aircontrol.tablet.settings.SettingsDataStore
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Persistent Android Foreground Service ("AIRCONTROL ACTIVE") that owns:
 * - CameraManager (CameraX ImageAnalysis)
 * - MediaPipeHandTracker (LIVE_STREAM HandLandmarker with square ROI projection fix)
 * - CalibrationManager + GestureRecognitionEngine
 * - SystemInteractionController (SystemCursorOverlay + AirControlAccessibilityService + AudioManager)
 *
 * Continues operating when the user leaves MainActivity and opens Chrome, YouTube, Gallery, Settings, or Home.
 */
class GestureControlForegroundService : LifecycleService(), MediaPipeHandTracker.Listener {

    private lateinit var settingsDataStore: SettingsDataStore
    private lateinit var calibrationManager: CalibrationManager
    private lateinit var cursorOverlay: SystemCursorOverlay
    private lateinit var systemController: SystemInteractionController
    private lateinit var gestureEngine: GestureRecognitionEngine
    private lateinit var handTracker: MediaPipeHandTracker
    private lateinit var cameraManager: CameraManager

    @Volatile
    private var currentSettings = GestureSettings()

    private var lastFrameTimestampMs = 0L
    private var smoothedFps = 30

    companion object {
        const val CHANNEL_ID = "aircontrol_foreground_service_channel"
        const val NOTIFICATION_ID = 4101
        const val ACTION_START = "com.aircontrol.tablet.action.START_SERVICE"
        const val ACTION_STOP = "com.aircontrol.tablet.action.STOP_SERVICE"
        const val ACTION_CALIBRATE_POINT = "com.aircontrol.tablet.action.CALIBRATE_POINT"
        const val ACTION_RESET_CALIBRATION = "com.aircontrol.tablet.action.RESET_CALIBRATION"
        const val EXTRA_CORNER_INDEX = "extra_corner_index"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        settingsDataStore = SettingsDataStore(applicationContext)
        calibrationManager = CalibrationManager(applicationContext)
        cursorOverlay = SystemCursorOverlay(applicationContext)
        systemController = SystemInteractionController(applicationContext, cursorOverlay)
        gestureEngine = GestureRecognitionEngine(calibrationManager)
        handTracker = MediaPipeHandTracker(applicationContext, this)
        cameraManager = CameraManager(applicationContext, this) { imageProxy ->
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!powerManager.isInteractive) {
                imageProxy.close()
                return@CameraManager
            }
            handTracker.detectLiveStreamFrame(
                imageProxy = imageProxy,
                isFrontCameraMirrored = currentSettings.mirrorFrontCamera
            )
        }

        lifecycleScope.launch {
            settingsDataStore.settingsFlow.collectLatest { prefs ->
                currentSettings = prefs.gestureSettings
                cameraManager.setTargetFps(prefs.targetFps)
                cursorOverlay.setAppearance(prefs.cursorSizeScale, prefs.cursorOpacity)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_STOP -> {
                stopAirControlService()
                return START_NOT_STICKY
            }
            ACTION_CALIBRATE_POINT -> {
                val corner = intent.getIntExtra(EXTRA_CORNER_INDEX, 0)
                val currentTelemetry = ServiceStateRepository.telemetry.value
                calibrationManager.recordCalibrationPoint(
                    cornerIndex = corner,
                    rawX = currentTelemetry.rawLandmarkX,
                    rawY = currentTelemetry.rawLandmarkY
                )
                return START_STICKY
            }
            ACTION_RESET_CALIBRATION -> {
                calibrationManager.resetCalibration()
                return START_STICKY
            }
        }

        val notification = buildForegroundNotification("Tracking active above all Android apps")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        systemController.startOverlay()
        handTracker.initialize()
        cameraManager.startCamera()
        ServiceStateRepository.setServiceRunning(true)

        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        cursorOverlay.onConfigurationChanged()
        val (w, h, rot) = systemController.getDisplayMetrics()
        ServiceStateRepository.updateDisplayMetrics(w, h, rot, cursorOverlay.isAttached())
    }

    override fun onHandResult(bundle: MediaPipeHandTracker.ResultBundle) {
        val nowMs = SystemClock.uptimeMillis()
        if (lastFrameTimestampMs > 0L) {
            val delta = (nowMs - lastFrameTimestampMs).coerceAtLeast(1L)
            val instantFps = (1000L / delta).toInt().coerceIn(1, 60)
            smoothedFps = ((smoothedFps * 0.8f) + (instantFps * 0.2f)).toInt()
        }
        lastFrameTimestampMs = nowMs

        val (displayWidth, displayHeight, rotationDeg) = systemController.getDisplayMetrics()
        val firstHand = bundle.result.landmarks().firstOrNull()

        val gestureFrame = gestureEngine.processLandmarks(
            landmarks = firstHand,
            displayWidth = displayWidth,
            displayHeight = displayHeight,
            displayRotationDegrees = rotationDeg,
            settings = currentSettings,
            nowMs = nowMs
        )

        systemController.onGestureFrame(gestureFrame, nowMs)
        ServiceStateRepository.updateFromGestureFrame(
            frame = gestureFrame,
            fps = smoothedFps,
            inferenceMs = bundle.inferenceTimeMs,
            overlayAttached = cursorOverlay.isAttached()
        )
    }

    override fun onHandError(message: String) {
        ServiceStateRepository.recordAction("Camera/MP Warning: $message")
    }

    private fun stopAirControlService() {
        cameraManager.stopCamera()
        handTracker.close()
        systemController.stopOverlay()
        ServiceStateRepository.setServiceRunning(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cameraManager.stopCamera()
        handTracker.close()
        systemController.stopOverlay()
        ServiceStateRepository.setServiceRunning(false)
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(statusText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, GestureControlForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(getString(R.string.notification_title)) // "AIRCONTROL ACTIVE"
            .setContentText(statusText)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openPendingIntent)
            .addAction(
                android.R.drawable.ic_menu_view,
                getString(R.string.action_open_aircontrol),
                openPendingIntent
            )
            .addAction(
                android.R.drawable.ic_media_pause,
                getString(R.string.action_stop),
                stopPendingIntent
            )
            .build()
    }
}
