package com.aircontrol.tablet.controller

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import com.aircontrol.tablet.accessibility.AirControlAccessibilityService
import com.aircontrol.tablet.gesture.GestureFrameOutput
import com.aircontrol.tablet.gesture.GestureState
import com.aircontrol.tablet.overlay.SystemCursorOverlay
import com.aircontrol.tablet.service.ServiceStateRepository
import kotlin.math.abs

/**
 * Coordinates all Android OS system-level actions:
 * 1. SystemCursorOverlay (WindowManager TYPE_APPLICATION_OVERLAY floating pointer window)
 * 2. AirControlAccessibilityService (dispatchGesture for system-wide tap & scroll, performGlobalAction for Recents)
 * 3. AudioManager (STREAM_MUSIC volume adjustments with system UI panel)
 */
class SystemInteractionController(
    context: Context,
    private val cursorOverlay: SystemCursorOverlay
) {
    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var scrollAccumulatorPx = 0f
    private var lastScrollDispatchMs = 0L

    fun startOverlay() {
        mainHandler.post {
            val attached = cursorOverlay.attachOverlay()
            val (w, h, rot) = cursorOverlay.getDisplayMetrics()
            ServiceStateRepository.updateDisplayMetrics(w, h, rot, attached && cursorOverlay.isAttached())
        }
    }

    fun stopOverlay() {
        mainHandler.post {
            cursorOverlay.detachOverlay()
            val (w, h, rot) = cursorOverlay.getDisplayMetrics()
            ServiceStateRepository.updateDisplayMetrics(w, h, rot, false)
        }
    }

    fun getDisplayMetrics(): Triple<Int, Int, Int> {
        return cursorOverlay.getDisplayMetrics()
    }

    fun onGestureFrame(frame: GestureFrameOutput, nowMs: Long) {
        // 1. Update floating system-wide overlay cursor on main UI thread
        mainHandler.post {
            if (!cursorOverlay.isAttached()) {
                cursorOverlay.attachOverlay()
            }
            cursorOverlay.updateCursor(
                screenX = frame.displayX,
                screenY = frame.displayY,
                gestureState = frame.state,
                triggerClickPulse = frame.triggerClick
            )
        }

        // 2. If Open Palm Pause is active, immediately freeze all system actions
        if (frame.isPausedByPalm || frame.state == GestureState.OPEN_PALM_PAUSED) {
            scrollAccumulatorPx = 0f
            return
        }

        val accessibilityService = AirControlAccessibilityService.instance

        // 3. System-Wide Pinch Tap at (displayX, displayY) in whatever app is underneath
        if (frame.triggerClick) {
            accessibilityService?.dispatchTap(frame.displayX, frame.displayY)
            ServiceStateRepository.recordAction("TAP (${frame.displayX.toInt()}, ${frame.displayY.toInt()})")
        }

        // 4. System-Wide 2-Finger Scroll at cursor position
        if (frame.state == GestureState.TWO_FINGER_SCROLL && abs(frame.scrollDeltaY) > 1.5f) {
            scrollAccumulatorPx += frame.scrollDeltaY
            if (abs(scrollAccumulatorPx) >= 55f && (nowMs - lastScrollDispatchMs) >= 120L) {
                accessibilityService?.dispatchVerticalScroll(
                    centerX = frame.displayX,
                    centerY = frame.displayY,
                    deltaY = scrollAccumulatorPx
                )
                lastScrollDispatchMs = nowMs
                ServiceStateRepository.recordAction(
                    if (scrollAccumulatorPx > 0) "SCROLL DOWN" else "SCROLL UP"
                )
                scrollAccumulatorPx = 0f
            }
        } else {
            scrollAccumulatorPx = 0f
        }

        // 5. System-Wide 3-Finger Media Volume via AudioManager
        if (frame.state == GestureState.THREE_FINGER_VOLUME && frame.volumeStepDelta != 0) {
            adjustSystemMediaVolume(frame.volumeStepDelta)
        }

        // 6. System-Wide 4-Finger Recent Apps Overview
        if (frame.triggerRecents) {
            accessibilityService?.openRecentApps()
            ServiceStateRepository.recordAction("GLOBAL_ACTION_RECENTS")
        }
    }

    private fun adjustSystemMediaVolume(stepDelta: Int) {
        val direction = if (stepDelta > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        val steps = abs(stepDelta).coerceAtMost(3)
        repeat(steps) {
            audioManager.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                direction,
                AudioManager.FLAG_SHOW_UI
            )
        }
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val pct = ((current.toFloat() / maxVol.toFloat()) * 100f).toInt()
        ServiceStateRepository.recordVolumeChange(pct)
    }
}
