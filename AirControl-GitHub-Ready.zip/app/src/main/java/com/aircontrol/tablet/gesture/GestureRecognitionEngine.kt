package com.aircontrol.tablet.gesture

import com.aircontrol.tablet.calibration.CalibrationManager
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

enum class GestureState {
    IDLE,
    CURSOR_MOVE,
    PINCH_CLICK,
    TWO_FINGER_SCROLL,
    THREE_FINGER_VOLUME,
    FOUR_FINGER_RECENTS,
    OPEN_PALM_PAUSED,
    HAND_LOST
}

data class GestureSettings(
    val cursorSpeed: Float = 1.35f,
    val smoothingAlpha: Float = 0.28f,
    val pinchRatioThreshold: Float = 0.29f,
    val scrollSensitivity: Float = 1.25f,
    val volumeSensitivity: Float = 1.15f,
    val mirrorFrontCamera: Boolean = true,
    val activeZoneMargin: Float = 0.14f,
    val enableOneFingerCursor: Boolean = true,
    val enablePinchClick: Boolean = true,
    val enableOpenPalmPause: Boolean = true,
    val enableTwoFingerScroll: Boolean = true,
    val enableThreeFingerVolume: Boolean = true,
    val enableFourFingerRecents: Boolean = true
)

data class GestureFrameOutput(
    val state: GestureState,
    val rawLandmarkX: Float,
    val rawLandmarkY: Float,
    val calibratedX: Float,
    val calibratedY: Float,
    val smoothedX: Float,
    val smoothedY: Float,
    val displayX: Float,
    val displayY: Float,
    val displayWidth: Int,
    val displayHeight: Int,
    val displayRotationDegrees: Int,
    val isPinching: Boolean,
    val triggerClick: Boolean,
    val scrollDeltaY: Float,
    val volumeStepDelta: Int,
    val triggerRecents: Boolean,
    val isPausedByPalm: Boolean,
    val extendedFingerCount: Int,
    val pinchRatio: Float
)

/**
 * Pure Kotlin state machine for AirControl.
 * Converts MediaPipe Hand Landmarks into physical Android display coordinates
 * ((0,0) -> (displayWidth, displayHeight)) using CalibrationManager + EMA smoothing + dead-zone filtering.
 */
class GestureRecognitionEngine(
    private val calibrationManager: CalibrationManager
) {
    private var smoothedNormX = 0.5f
    private var smoothedNormY = 0.5f
    private var smoothedScreenX = -1f
    private var smoothedScreenY = -1f
    private var smoothedPinchRatio = 1.0f

    // Hysteresis pinch state
    private var isPinchLatched = false
    private var pinchConfirmFrames = 0
    private var lastClickTimestampMs = 0L

    // Anchor coordinates at the moment a pinch starts (prevents cursor drift on tap)
    private var pinchAnchorScreenX = 0f
    private var pinchAnchorScreenY = 0f

    // Continuous gesture state
    private var prevScrollNormalizedY: Float? = null
    private var prevVolumeNormalizedY: Float? = null
    private var volumeAccumulator = 0f

    // Recents cooldown & confirmation
    private var lastRecentsTimestampMs = 0L
    private var fourFingerConfirmFrames = 0

    // Hand loss tracking
    private var lastHandDetectedMs = 0L

    companion object {
        private const val DEAD_ZONE_PX = 1.8f
        private const val CLICK_COOLDOWN_MS = 280L
        private const val RECENTS_COOLDOWN_MS = 1600L
        private const val HAND_LOST_STOP_MOVEMENT_MS = 280L
    }

    fun processLandmarks(
        landmarks: List<NormalizedLandmark>?,
        displayWidth: Int,
        displayHeight: Int,
        displayRotationDegrees: Int,
        settings: GestureSettings,
        nowMs: Long
    ): GestureFrameOutput {
        val safeWidth = max(1, displayWidth)
        val safeHeight = max(1, displayHeight)

        if (landmarks == null || landmarks.size < 21) {
            isPinchLatched = false
            pinchConfirmFrames = 0
            prevScrollNormalizedY = null
            prevVolumeNormalizedY = null
            fourFingerConfirmFrames = 0

            val fallbackX = if (smoothedScreenX < 0f) safeWidth / 2f else smoothedScreenX
            val fallbackY = if (smoothedScreenY < 0f) safeHeight / 2f else smoothedScreenY

            return GestureFrameOutput(
                state = GestureState.HAND_LOST,
                rawLandmarkX = 0.5f,
                rawLandmarkY = 0.5f,
                calibratedX = 0.5f,
                calibratedY = 0.5f,
                smoothedX = fallbackX,
                smoothedY = fallbackY,
                displayX = fallbackX,
                displayY = fallbackY,
                displayWidth = safeWidth,
                displayHeight = safeHeight,
                displayRotationDegrees = displayRotationDegrees,
                isPinching = false,
                triggerClick = false,
                scrollDeltaY = 0f,
                volumeStepDelta = 0,
                triggerRecents = false,
                isPausedByPalm = false,
                extendedFingerCount = 0,
                pinchRatio = 1.0f
            )
        }

        lastHandDetectedMs = nowMs

        val wrist = landmarks[0]
        val thumbCmc = landmarks[1]
        val thumbMcp = landmarks[2]
        val thumbIp = landmarks[3]
        val thumbTip = landmarks[4]
        val indexMcp = landmarks[5]
        val indexPip = landmarks[6]
        val indexDip = landmarks[7]
        val indexTip = landmarks[8]
        val middleMcp = landmarks[9]
        val middlePip = landmarks[10]
        val middleTip = landmarks[12]
        val ringMcp = landmarks[13]
        val ringPip = landmarks[14]
        val ringTip = landmarks[16]
        val pinkyMcp = landmarks[17]
        val pinkyPip = landmarks[18]
        val pinkyTip = landmarks[20]

        // Scale-invariant palm size reference
        val palmScale = max(
            0.055f,
            max(
                distance2D(wrist, middleMcp),
                distance2D(indexMcp, pinkyMcp)
            )
        )

        // Finger extension detection
        val indexExtended = isFingerExtended(wrist, indexMcp, indexPip, indexTip)
        val middleExtended = isFingerExtended(wrist, middleMcp, middlePip, middleTip)
        val ringExtended = isFingerExtended(wrist, ringMcp, ringPip, ringTip)
        val pinkyExtended = isFingerExtended(wrist, pinkyMcp, pinkyPip, pinkyTip)
        val thumbExtended = isThumbExtended(wrist, thumbCmc, thumbMcp, thumbIp, thumbTip, pinkyMcp, palmScale)

        val nonThumbCount = listOf(indexExtended, middleExtended, ringExtended, pinkyExtended).count { it }
        val totalExtended = nonThumbCount + if (thumbExtended) 1 else 0

        // Scale-invariant pinch ratio (Thumb Tip #4 to Index Tip #8 / Dip #7)
        val tipDist = distance2D(thumbTip, indexTip)
        val dipDist = distance2D(thumbTip, indexDip) * 1.08f
        val rawPinchRatio = min(tipDist, dipDist) / palmScale
        smoothedPinchRatio = if (rawPinchRatio < smoothedPinchRatio) {
            smoothedPinchRatio + 0.72f * (rawPinchRatio - smoothedPinchRatio)
        } else {
            smoothedPinchRatio + 0.45f * (rawPinchRatio - smoothedPinchRatio)
        }

        // Raw index fingertip landmark (#8)
        val rawX = indexTip.x()
        val rawY = indexTip.y()

        // 1. Calibration ROI mapping (maps comfortable camera zone to 0.0..1.0 full display)
        val (calibratedX, calibratedY) = calibrationManager.mapLandmarkToCalibratedNormalized(
            rawX = rawX,
            rawY = rawY,
            mirrorFrontCamera = settings.mirrorFrontCamera,
            fallbackMargin = settings.activeZoneMargin,
            cursorSpeed = settings.cursorSpeed
        )

        // 2. Exponential Moving Average (EMA) smoothing on normalized coordinates
        val alpha = settings.smoothingAlpha.coerceIn(0.08f, 0.85f)
        smoothedNormX += alpha * (calibratedX - smoothedNormX)
        smoothedNormY += alpha * (calibratedY - smoothedNormY)

        // 3. Map to full physical display dimensions (0,0) -> (displayWidth, displayHeight)
        val candidateScreenX = (smoothedNormX * safeWidth).coerceIn(0f, safeWidth.toFloat())
        val candidateScreenY = (smoothedNormY * safeHeight).coerceIn(0f, safeHeight.toFloat())

        if (smoothedScreenX < 0f || smoothedScreenY < 0f) {
            smoothedScreenX = candidateScreenX
            smoothedScreenY = candidateScreenY
        } else {
            val deltaPx = hypot(candidateScreenX - smoothedScreenX, candidateScreenY - smoothedScreenY)
            if (deltaPx > DEAD_ZONE_PX) {
                smoothedScreenX = candidateScreenX
                smoothedScreenY = candidateScreenY
            }
        }

        // Priority 1: Open Palm — Universal Pause / Freeze (all 5 fingers extended & thumb separated)
        val isOpenPalm = settings.enableOpenPalmPause &&
            indexExtended && middleExtended && ringExtended && pinkyExtended &&
            thumbExtended && rawPinchRatio > 0.48f

        if (isOpenPalm) {
            isPinchLatched = false
            pinchConfirmFrames = 0
            prevScrollNormalizedY = null
            prevVolumeNormalizedY = null
            fourFingerConfirmFrames = 0
            return GestureFrameOutput(
                state = GestureState.OPEN_PALM_PAUSED,
                rawLandmarkX = rawX,
                rawLandmarkY = rawY,
                calibratedX = calibratedX,
                calibratedY = calibratedY,
                smoothedX = smoothedScreenX,
                smoothedY = smoothedScreenY,
                displayX = smoothedScreenX,
                displayY = smoothedScreenY,
                displayWidth = safeWidth,
                displayHeight = safeHeight,
                displayRotationDegrees = displayRotationDegrees,
                isPinching = false,
                triggerClick = false,
                scrollDeltaY = 0f,
                volumeStepDelta = 0,
                triggerRecents = false,
                isPausedByPalm = true,
                extendedFingerCount = 5,
                pinchRatio = smoothedPinchRatio
            )
        }

        // Priority 2: Pinch Click (Thumb #4 + Index #8 with hysteresis + release gate)
        val enterThreshold = settings.pinchRatioThreshold
        val exitThreshold = settings.pinchRatioThreshold + 0.11f
        val canEvaluatePinch = settings.enablePinchClick && (!ringExtended || !pinkyExtended)

        var triggerClick = false
        if (canEvaluatePinch) {
            if (!isPinchLatched) {
                if (smoothedPinchRatio < enterThreshold) {
                    if (pinchConfirmFrames == 0) {
                        pinchAnchorScreenX = smoothedScreenX
                        pinchAnchorScreenY = smoothedScreenY
                    }
                    pinchConfirmFrames++
                    if (pinchConfirmFrames >= 1 && (nowMs - lastClickTimestampMs) >= CLICK_COOLDOWN_MS) {
                        isPinchLatched = true
                        triggerClick = true
                        lastClickTimestampMs = nowMs
                        smoothedScreenX = pinchAnchorScreenX
                        smoothedScreenY = pinchAnchorScreenY
                    }
                } else {
                    pinchConfirmFrames = 0
                }
            } else {
                // Hold cursor steady at pinch anchor so tap doesn't slip off target button
                smoothedScreenX = pinchAnchorScreenX
                smoothedScreenY = pinchAnchorScreenY
                if (smoothedPinchRatio > exitThreshold) {
                    isPinchLatched = false
                    pinchConfirmFrames = 0
                }
            }
        } else {
            isPinchLatched = false
            pinchConfirmFrames = 0
        }

        if (isPinchLatched || triggerClick) {
            prevScrollNormalizedY = null
            prevVolumeNormalizedY = null
            fourFingerConfirmFrames = 0
            return GestureFrameOutput(
                state = GestureState.PINCH_CLICK,
                rawLandmarkX = rawX,
                rawLandmarkY = rawY,
                calibratedX = calibratedX,
                calibratedY = calibratedY,
                smoothedX = smoothedScreenX,
                smoothedY = smoothedScreenY,
                displayX = smoothedScreenX,
                displayY = smoothedScreenY,
                displayWidth = safeWidth,
                displayHeight = safeHeight,
                displayRotationDegrees = displayRotationDegrees,
                isPinching = true,
                triggerClick = triggerClick,
                scrollDeltaY = 0f,
                volumeStepDelta = 0,
                triggerRecents = false,
                isPausedByPalm = false,
                extendedFingerCount = totalExtended,
                pinchRatio = smoothedPinchRatio
            )
        }

        // Priority 3: Four Fingers (Thumb folded) — Android Recent Apps
        if (settings.enableFourFingerRecents &&
            indexExtended && middleExtended && ringExtended && pinkyExtended && !thumbExtended
        ) {
            prevScrollNormalizedY = null
            prevVolumeNormalizedY = null
            fourFingerConfirmFrames++
            var triggerRecents = false
            if (fourFingerConfirmFrames >= 4 && (nowMs - lastRecentsTimestampMs) >= RECENTS_COOLDOWN_MS) {
                triggerRecents = true
                lastRecentsTimestampMs = nowMs
                fourFingerConfirmFrames = 0
            }
            return GestureFrameOutput(
                state = GestureState.FOUR_FINGER_RECENTS,
                rawLandmarkX = rawX,
                rawLandmarkY = rawY,
                calibratedX = calibratedX,
                calibratedY = calibratedY,
                smoothedX = smoothedScreenX,
                smoothedY = smoothedScreenY,
                displayX = smoothedScreenX,
                displayY = smoothedScreenY,
                displayWidth = safeWidth,
                displayHeight = safeHeight,
                displayRotationDegrees = displayRotationDegrees,
                isPinching = false,
                triggerClick = false,
                scrollDeltaY = 0f,
                volumeStepDelta = 0,
                triggerRecents = triggerRecents,
                isPausedByPalm = false,
                extendedFingerCount = 4,
                pinchRatio = smoothedPinchRatio
            )
        } else {
            fourFingerConfirmFrames = 0
        }

        // Priority 4: Three Fingers (Index + Middle + Ring) — System Media Volume
        if (settings.enableThreeFingerVolume &&
            indexExtended && middleExtended && ringExtended && !pinkyExtended
        ) {
            prevScrollNormalizedY = null
            val avgY = (indexTip.y() + middleTip.y() + ringTip.y()) / 3f
            var volumeSteps = 0
            val prevY = prevVolumeNormalizedY
            if (prevY != null) {
                val deltaY = (prevY - avgY) * settings.volumeSensitivity
                volumeAccumulator += deltaY
                val stepThreshold = 0.042f
                if (abs(volumeAccumulator) >= stepThreshold) {
                    volumeSteps = (volumeAccumulator / stepThreshold).toInt()
                    volumeAccumulator -= volumeSteps * stepThreshold
                }
            }
            prevVolumeNormalizedY = avgY

            return GestureFrameOutput(
                state = GestureState.THREE_FINGER_VOLUME,
                rawLandmarkX = rawX,
                rawLandmarkY = rawY,
                calibratedX = calibratedX,
                calibratedY = calibratedY,
                smoothedX = smoothedScreenX,
                smoothedY = smoothedScreenY,
                displayX = smoothedScreenX,
                displayY = smoothedScreenY,
                displayWidth = safeWidth,
                displayHeight = safeHeight,
                displayRotationDegrees = displayRotationDegrees,
                isPinching = false,
                triggerClick = false,
                scrollDeltaY = 0f,
                volumeStepDelta = volumeSteps,
                triggerRecents = false,
                isPausedByPalm = false,
                extendedFingerCount = 3,
                pinchRatio = smoothedPinchRatio
            )
        } else {
            prevVolumeNormalizedY = null
            volumeAccumulator = 0f
        }

        // Priority 5: Two Fingers (Index + Middle) — Smooth Vertical Scroll
        if (settings.enableTwoFingerScroll &&
            indexExtended && middleExtended && !ringExtended && !pinkyExtended
        ) {
            val avgY = (indexTip.y() + middleTip.y()) / 2f
            var scrollPx = 0f
            val prevY = prevScrollNormalizedY
            if (prevY != null) {
                val dy = avgY - prevY
                if (abs(dy) > 0.004f) {
                    scrollPx = dy * safeHeight * 1.45f * settings.scrollSensitivity
                }
            }
            prevScrollNormalizedY = avgY

            return GestureFrameOutput(
                state = GestureState.TWO_FINGER_SCROLL,
                rawLandmarkX = rawX,
                rawLandmarkY = rawY,
                calibratedX = calibratedX,
                calibratedY = calibratedY,
                smoothedX = smoothedScreenX,
                smoothedY = smoothedScreenY,
                displayX = smoothedScreenX,
                displayY = smoothedScreenY,
                displayWidth = safeWidth,
                displayHeight = safeHeight,
                displayRotationDegrees = displayRotationDegrees,
                isPinching = false,
                triggerClick = false,
                scrollDeltaY = scrollPx,
                volumeStepDelta = 0,
                triggerRecents = false,
                isPausedByPalm = false,
                extendedFingerCount = 2,
                pinchRatio = smoothedPinchRatio
            )
        } else {
            prevScrollNormalizedY = null
        }

        // Priority 6: One Finger (Index extended) — System-Wide Cursor Move
        val isCursorActive = settings.enableOneFingerCursor && (indexExtended || nonThumbCount <= 1)
        return GestureFrameOutput(
            state = if (isCursorActive) GestureState.CURSOR_MOVE else GestureState.IDLE,
            rawLandmarkX = rawX,
            rawLandmarkY = rawY,
            calibratedX = calibratedX,
            calibratedY = calibratedY,
            smoothedX = smoothedScreenX,
            smoothedY = smoothedScreenY,
            displayX = smoothedScreenX,
            displayY = smoothedScreenY,
            displayWidth = safeWidth,
            displayHeight = safeHeight,
            displayRotationDegrees = displayRotationDegrees,
            isPinching = false,
            triggerClick = false,
            scrollDeltaY = 0f,
            volumeStepDelta = 0,
            triggerRecents = false,
            isPausedByPalm = false,
            extendedFingerCount = max(1, totalExtended),
            pinchRatio = smoothedPinchRatio
        )
    }

    private fun isFingerExtended(
        wrist: NormalizedLandmark,
        mcp: NormalizedLandmark,
        pip: NormalizedLandmark,
        tip: NormalizedLandmark
    ): Boolean {
        val wristToTip = distance2D(wrist, tip)
        val wristToPip = distance2D(wrist, pip)
        val wristToMcp = distance2D(wrist, mcp)
        return wristToTip > wristToPip * 1.12f && wristToTip > wristToMcp * 1.32f
    }

    private fun isThumbExtended(
        wrist: NormalizedLandmark,
        cmc: NormalizedLandmark,
        mcp: NormalizedLandmark,
        ip: NormalizedLandmark,
        tip: NormalizedLandmark,
        pinkyMcp: NormalizedLandmark,
        palmScale: Float
    ): Boolean {
        val tipToPinkyBase = distance2D(tip, pinkyMcp)
        val mcpToPinkyBase = distance2D(mcp, pinkyMcp)
        val cmcToTip = distance2D(cmc, tip)
        val cmcToIp = distance2D(cmc, ip)
        val wristToTip = distance2D(wrist, tip)
        return tipToPinkyBase > mcpToPinkyBase * 1.16f &&
            cmcToTip > cmcToIp * 1.12f &&
            wristToTip > palmScale * 0.92f
    }

    private fun distance2D(a: NormalizedLandmark, b: NormalizedLandmark): Float {
        return hypot(a.x() - b.x(), a.y() - b.y())
    }
}
