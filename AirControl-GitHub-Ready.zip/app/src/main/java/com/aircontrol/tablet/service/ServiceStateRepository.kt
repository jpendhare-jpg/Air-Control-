package com.aircontrol.tablet.service

import com.aircontrol.tablet.gesture.CursorVisualState
import com.aircontrol.tablet.gesture.GestureType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Real-time system-wide telemetry and debug state emitted by [GestureControlService].
 * Allows [com.aircontrol.tablet.ui.MainActivity] to observe live tracking and coordinate
 * metrics when open, while [GestureControlService] continues running independently when
 * MainActivity is backgrounded or destroyed.
 */
data class SystemDebugTelemetry(
    val serviceRunning: Boolean = false,
    val systemCursorActive: Boolean = false,
    val overlayPermissionGranted: Boolean = false,
    val accessibilityServiceEnabled: Boolean = false,
    val displayWidth: Int = 2560,
    val displayHeight: Int = 1600,
    val cameraWidth: Int = 1280,
    val cameraHeight: Int = 720,
    val cameraRotation: Int = 0,
    val mirrorState: Boolean = true,
    val cursorX: Float = 1280f,
    val cursorY: Float = 800f,
    val cursorState: CursorVisualState = CursorVisualState.NORMAL,
    val gesture: GestureType = GestureType.NONE,
    val gestureConfidence: Int = 0,
    val fps: Int = 0
)

object ServiceStateRepository {
    private val _telemetry = MutableStateFlow(SystemDebugTelemetry())
    val telemetry: StateFlow<SystemDebugTelemetry> = _telemetry.asStateFlow()

    fun updateTelemetry(transform: (SystemDebugTelemetry) -> SystemDebugTelemetry) {
        _telemetry.update(transform)
    }
}
