package com.aircontrol.tablet

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.aircontrol.tablet.accessibility.AirControlAccessibilityService
import com.aircontrol.tablet.service.GestureControlForegroundService
import com.aircontrol.tablet.service.ServiceStateRepository
import com.aircontrol.tablet.settings.AirControlPreferences
import com.aircontrol.tablet.settings.SettingsDataStore
import kotlinx.coroutines.launch

/**
 * Main Tablet Control Deck Activity for AirControl.
 * Verifies real Android OS permissions (CAMERA, SYSTEM_ALERT_WINDOW, AccessibilityService),
 * starts/stops GestureControlForegroundService, provides 4-point screen corner calibration,
 * displays the 13-field Developer Coordinate Debug Panel, and launches real external Android apps
 * (Chrome, YouTube, Gallery, Settings, or Android Home Screen) to test the system-wide overlay cursor.
 */
class MainActivity : ComponentActivity() {

    private lateinit var settingsDataStore: SettingsDataStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsDataStore = SettingsDataStore(applicationContext)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF06090F),
                    surface = Color(0xFF0D131F),
                    primary = Color(0xFF00F0FF),
                    secondary = Color(0xFF10B981)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AirControlTabletScreen(settingsDataStore = settingsDataStore)
                }
            }
        }
    }
}

@Composable
fun AirControlTabletScreen(settingsDataStore: SettingsDataStore) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    val telemetry by ServiceStateRepository.telemetry.collectAsState()
    val preferences by settingsDataStore.settingsFlow.collectAsState(initial = AirControlPreferences())

    var hasCameraPermission by remember { mutableStateOf(checkCameraGranted(context)) }
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var hasAccessibilityEnabled by remember { mutableStateOf(isAccessibilityServiceEnabled(context)) }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasCameraPermission = checkCameraGranted(context)
                hasOverlayPermission = Settings.canDrawOverlays(context)
                hasAccessibilityEnabled = isAccessibilityServiceEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val allPermissionsReady = hasCameraPermission && hasOverlayPermission && hasAccessibilityEnabled

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Header & Service Control Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0D131F), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AIRCONTROL // ANDROID TABLET SYSTEM CONTROLLER",
                    color = Color(0xFF00F0FF),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "System-Wide WindowManager Overlay + Accessibility Gesture Engine",
                    color = Color(0xFFF8FAFC),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = {
                        if (!hasCameraPermission) {
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            return@Button
                        }
                        if (!hasOverlayPermission) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                            return@Button
                        }
                        if (!hasAccessibilityEnabled) {
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            return@Button
                        }
                        val serviceIntent = Intent(context, GestureControlForegroundService::class.java).apply {
                            action = GestureControlForegroundService.ACTION_START
                        }
                        ContextCompat.startForegroundService(context, serviceIntent)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (telemetry.isServiceRunning) Color(0xFF10B981) else Color(0xFF00F0FF),
                        contentColor = Color(0xFF05080E)
                    )
                ) {
                    Text(
                        text = if (telemetry.isServiceRunning) "AIRCONTROL ACTIVE" else "START AIR CONTROL",
                        fontWeight = FontWeight.Bold
                    )
                }

                if (telemetry.isServiceRunning) {
                    OutlinedButton(
                        onClick = {
                            val stopIntent = Intent(context, GestureControlForegroundService::class.java).apply {
                                action = GestureControlForegroundService.ACTION_STOP
                            }
                            context.startService(stopIntent)
                        }
                    ) {
                        Text("STOP SERVICE", color = Color(0xFFF43F5E), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Required 5-Line System Readiness Checklist + Developer Coordinate Debug Panel
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Left Column: System Status Checklist & Permission Gateways
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF0D131F), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ANDROID SYSTEM STATUS CHECKLIST",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                SystemStatusRow(
                    label = "CAMERA",
                    statusText = if (hasCameraPermission) "✓ Granted" else "✗ Required",
                    isReady = hasCameraPermission,
                    actionLabel = if (!hasCameraPermission) "Grant Camera" else null,
                    onAction = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) }
                )

                SystemStatusRow(
                    label = "OVERLAY",
                    statusText = if (hasOverlayPermission) "✓ Granted" else "✗ Required",
                    isReady = hasOverlayPermission,
                    actionLabel = if (!hasOverlayPermission) "Grant Overlay" else null,
                    onAction = {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                        )
                    }
                )

                SystemStatusRow(
                    label = "ACCESSIBILITY",
                    statusText = if (hasAccessibilityEnabled) "✓ Enabled" else "✗ Disabled",
                    isReady = hasAccessibilityEnabled,
                    actionLabel = if (!hasAccessibilityEnabled) "Enable Service" else null,
                    onAction = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                )

                SystemStatusRow(
                    label = "FOREGROUND SERVICE",
                    statusText = if (telemetry.isServiceRunning) "✓ Running" else "Stopped",
                    isReady = telemetry.isServiceRunning,
                    actionLabel = null,
                    onAction = {}
                )

                SystemStatusRow(
                    label = "SYSTEM CURSOR",
                    statusText = if (telemetry.isOverlayAttached) "✓ Active" else "Inactive",
                    isReady = telemetry.isOverlayAttached,
                    actionLabel = null,
                    onAction = {}
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "TEST OUTSIDE AIRCONTROL (REAL ANDROID APPS)",
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { launchHomeScreen(context) }) {
                        Text("Home Screen", color = Color(0xFFF8FAFC), fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { launchExternalPackage(context, "com.android.chrome", "https://www.google.com") }) {
                        Text("Open Chrome", color = Color(0xFFF8FAFC), fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { launchExternalPackage(context, "com.google.android.youtube", "https://www.youtube.com") }) {
                        Text("Open YouTube", color = Color(0xFFF8FAFC), fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }) {
                        Text("Android Settings", color = Color(0xFFF8FAFC), fontSize = 12.sp)
                    }
                }
            }

            // Right Column: 13-Field Developer Coordinate & Gesture Debug Panel
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF0D131F), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "DEVELOPER COORDINATE & OVERLAY TELEMETRY",
                    color = Color(0xFF00F0FF),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                DebugMetricRow("rawLandmarkX / Y", "${"%.3f".format(telemetry.rawLandmarkX)}, ${"%.3f".format(telemetry.rawLandmarkY)}")
                DebugMetricRow("calibratedX / Y", "${"%.3f".format(telemetry.calibratedX)}, ${"%.3f".format(telemetry.calibratedY)}")
                DebugMetricRow("smoothedX / Y", "${telemetry.smoothedX.toInt()} px, ${telemetry.smoothedY.toInt()} px")
                DebugMetricRow("displayX / displayY", "(${telemetry.displayX.toInt()}, ${telemetry.displayY.toInt()})")
                DebugMetricRow("displayWidth / Height", "${telemetry.displayWidth} x ${telemetry.displayHeight} px")
                DebugMetricRow("displayRotation", "${telemetry.displayRotationDegrees}°")
                DebugMetricRow("overlayAttached", telemetry.isOverlayAttached.toString())
                DebugMetricRow("accessibilityConnected", hasAccessibilityEnabled.toString())
                DebugMetricRow("foregroundServiceRunning", telemetry.isServiceRunning.toString())
                DebugMetricRow("currentGesture", "${telemetry.gestureState.name} (pinch=${"%.2f".format(telemetry.pinchRatio)})")
                DebugMetricRow("cameraFps / inference", "${telemetry.fps} FPS (${telemetry.inferenceTimeMs} ms)")
                DebugMetricRow("lastDispatchedAction", telemetry.lastActionLabel)
            }
        }

        // 4-Corner Full-Display Calibration & Sensitivity Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF0D131F), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "4-POINT PHYSICAL DISPLAY CALIBRATION",
                    color = Color(0xFF00F0FF),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Point your index finger at each physical tablet corner and tap its button so your comfortable hand range maps across (0,0) -> (${telemetry.displayWidth}, ${telemetry.displayHeight}).",
                    color = Color(0xFF94A3B8),
                    fontSize = 13.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { sendCalibrationPoint(context, 0) }) { Text("1. Top-Left") }
                    OutlinedButton(onClick = { sendCalibrationPoint(context, 1) }) { Text("2. Top-Right") }
                    OutlinedButton(onClick = { sendCalibrationPoint(context, 2) }) { Text("3. Bottom-Right") }
                    OutlinedButton(onClick = { sendCalibrationPoint(context, 3) }) { Text("4. Bottom-Left") }
                    OutlinedButton(onClick = { resetCalibration(context) }) { Text("Reset ROI") }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF0D131F), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "CURSOR & PINCH TUNING (DATASTORE)",
                    color = Color(0xFF00F0FF),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text("Cursor Speed (${"%.2f".format(preferences.gestureSettings.cursorSpeed)}x)", color = Color(0xFFF8FAFC), fontSize = 13.sp)
                Slider(
                    value = preferences.gestureSettings.cursorSpeed,
                    onValueChange = { coroutineScope.launch { settingsDataStore.updateCursorSpeed(it) } },
                    valueRange = 0.7f..2.2f
                )

                Text("EMA Smoothing Alpha (${"%.2f".format(preferences.gestureSettings.smoothingAlpha)})", color = Color(0xFFF8FAFC), fontSize = 13.sp)
                Slider(
                    value = preferences.gestureSettings.smoothingAlpha,
                    onValueChange = { coroutineScope.launch { settingsDataStore.updateSmoothingAlpha(it) } },
                    valueRange = 0.12f..0.75f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Mirror Front Camera Horizontally", color = Color(0xFFF8FAFC), fontSize = 13.sp)
                    Switch(
                        checked = preferences.gestureSettings.mirrorFrontCamera,
                        onCheckedChange = { coroutineScope.launch { settingsDataStore.updateMirrorCamera(it) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun SystemStatusRow(
    label: String,
    statusText: String,
    isReady: Boolean,
    actionLabel: String?,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF111827), RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$label:",
            color = Color(0xFFE2E8F0),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                text = statusText,
                color = if (isReady) Color(0xFF10B981) else Color(0xFFF59E0B),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            if (actionLabel != null) {
                OutlinedButton(onClick = onAction) {
                    Text(actionLabel, fontSize = 11.sp, color = Color(0xFF00F0FF))
                }
            }
        }
    }
}

@Composable
private fun DebugMetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = Color(0xFF94A3B8),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        )
        Text(
            text = value,
            color = Color(0xFFF8FAFC),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp
        )
    }
}

private fun checkCameraGranted(context: Context): Boolean {
    return ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    if (AirControlAccessibilityService.instance != null) return true
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
    return enabledServices.any {
        it.resolveInfo?.serviceInfo?.packageName == context.packageName &&
            it.resolveInfo?.serviceInfo?.name?.endsWith("AirControlAccessibilityService") == true
    }
}

private fun sendCalibrationPoint(context: Context, cornerIndex: Int) {
    val intent = Intent(context, GestureControlForegroundService::class.java).apply {
        action = GestureControlForegroundService.ACTION_CALIBRATE_POINT
        putExtra(GestureControlForegroundService.EXTRA_CORNER_INDEX, cornerIndex)
    }
    context.startService(intent)
}

private fun resetCalibration(context: Context) {
    val intent = Intent(context, GestureControlForegroundService::class.java).apply {
        action = GestureControlForegroundService.ACTION_RESET_CALIBRATION
    }
    context.startService(intent)
}

private fun launchHomeScreen(context: Context) {
    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_HOME)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(homeIntent)
}

private fun launchExternalPackage(context: Context, packageName: String, fallbackUrl: String) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (launchIntent != null) {
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
    } else {
        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(browserIntent)
    }
}
