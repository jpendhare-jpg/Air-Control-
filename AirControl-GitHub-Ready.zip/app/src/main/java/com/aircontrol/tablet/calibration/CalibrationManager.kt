package com.aircontrol.tablet.calibration

import kotlin.math.max
import kotlin.math.min

/**
 * Maps normalized front-camera fingertip coordinates [0f..1f] through the user's
 * 5-point calibration bounds (Top-Left, Top-Right, Bottom-Right, Bottom-Left, Center)
 * and sensitivity scaling into REAL PHYSICAL DISPLAY coordinates [0f..displayWidth, 0f..displayHeight].
 */
data class CalibrationBounds(
    val topLeftX: Float = 0.14f,
    val topLeftY: Float = 0.16f,
    val topRightX: Float = 0.86f,
    val topRightY: Float = 0.16f,
    val bottomRightX: Float = 0.86f,
    val bottomRightY: Float = 0.84f,
    val bottomLeftX: Float = 0.14f,
    val bottomLeftY: Float = 0.84f,
    val centerX: Float = 0.50f,
    val centerY: Float = 0.50f
)

class CalibrationManager {
    @Volatile
    var bounds: CalibrationBounds = CalibrationBounds()

    /**
     * Converts a mirror-corrected, rotation-corrected camera coordinate (normX, normY)
     * into a physical display pixel coordinate (displayX, displayY) capable of reaching
     * (0,0), (displayWidth,0), (0,displayHeight), and (displayWidth,displayHeight).
     */
    fun mapToPhysicalDisplay(
        normX: Float,
        normY: Float,
        sensitivity: Float,
        displayWidth: Int,
        displayHeight: Int
    ): Pair<Float, Float> {
        val b = bounds
        val minX = min(b.topLeftX, b.bottomLeftX)
        val maxX = max(b.topRightX, b.bottomRightX)
        val minY = min(b.topLeftY, b.topRightY)
        val maxY = max(b.bottomLeftY, b.bottomRightY)

        val spanX = max(0.15f, maxX - minX)
        val spanY = max(0.15f, maxY - minY)

        val centeredX = ((normX - minX) / spanX) - 0.5f
        val centeredY = ((normY - minY) / spanY) - 0.5f

        val scaledX = (0.5f + centeredX * sensitivity).coerceIn(0f, 1f)
        val scaledY = (0.5f + centeredY * sensitivity).coerceIn(0f, 1f)

        val displayX = scaledX * displayWidth.toFloat()
        val displayY = scaledY * displayHeight.toFloat()
        return Pair(displayX, displayY)
    }
}
