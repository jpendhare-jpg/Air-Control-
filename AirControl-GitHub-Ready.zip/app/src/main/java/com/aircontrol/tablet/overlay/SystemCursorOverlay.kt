package com.aircontrol.tablet.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.aircontrol.tablet.gesture.CursorVisualState
import com.aircontrol.tablet.gesture.GestureType
import kotlin.math.roundToInt

/**
 * Separate System-Wide Floating Overlay Window owned by [com.aircontrol.tablet.service.GestureControlForegroundService].
 *
 * Uses [WindowManager] with [WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY] and
 * [android.Manifest.permission.SYSTEM_ALERT_WINDOW].
 *
 * Designed as a compact, dedicated floating pointer window (88x88 px) positioned via
 * [WindowManager.updateViewLayout] with [WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN]
 * and [WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS] so that:
 * 1. The cursor center point can reach exact physical coordinates (0,0), top-right (W,0),
 *    bottom-left (0,H), and bottom-right (W,H) without WindowManager clamping the window inside edges.
 * 2. Because the window only occupies the pointer bounds (and is FLAG_NOT_TOUCHABLE | FLAG_NOT_FOCUSABLE),
 *    it never triggers Android 12+ full-screen untrusted-touch blocking when dispatching Accessibility taps
 *    to Chrome, YouTube, Gallery, Settings, Files, or Games.
 */
class SystemCursorOverlay(private val context: Context) {

    private val windowManager =
        context.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var pointerView: FloatingPointerView? = null
    private var pointerLayoutParams: WindowManager.LayoutParams? = null

    val isActive: Boolean
        get() = pointerView != null

    /**
     * Queries the true full physical display size in pixels (Portrait or Landscape).
     * Never uses Activity or Compose window bounds.
     */
    fun getPhysicalDisplaySize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.maximumWindowMetrics.bounds
            Pair(bounds.width(), bounds.height())
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(dm)
            Pair(dm.widthPixels, dm.heightPixels)
        }
    }

    /**
     * Queries the current physical display rotation (Surface.ROTATION_0, ROTATION_90, etc.)
     */
    fun getDisplayRotation(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.display?.rotation ?: 0
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.rotation
        }
    }

    fun show() {
        if (!Settings.canDrawOverlays(context) || pointerView != null) return

        val (physW, physH) = getPhysicalDisplaySize()
        val windowSizePx = POINTER_WINDOW_SIZE_PX
        val halfSize = windowSizePx / 2

        pointerLayoutParams = WindowManager.LayoutParams(
            windowSizePx,
            windowSizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (physW / 2) - halfSize
            y = (physH / 2) - halfSize
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        pointerView = FloatingPointerView(context)
        windowManager.addView(pointerView, pointerLayoutParams)
    }

    /**
     * Moves the separate floating overlay window so its center point sits at exact
     * physical display coordinate (displayX, displayY) across [0..displayWidth, 0..displayHeight].
     */
    fun updatePosition(
        displayX: Float,
        displayY: Float,
        state: CursorVisualState,
        gesture: GestureType,
        clickTriggered: Boolean
    ) {
        val view = pointerView ?: return
        val params = pointerLayoutParams ?: return
        val (physW, physH) = getPhysicalDisplaySize()

        val clampedX = displayX.coerceIn(0f, physW.toFloat())
        val clampedY = displayY.coerceIn(0f, physH.toFloat())
        val halfSize = POINTER_WINDOW_SIZE_PX / 2f

        params.x = (clampedX - halfSize).roundToInt()
        params.y = (clampedY - halfSize).roundToInt()

        view.visualState = state
        view.activeGesture = gesture
        if (clickTriggered) {
            view.triggerClickPulse()
        }
        view.postInvalidateOnAnimation()

        try {
            windowManager.updateViewLayout(view, params)
        } catch (_: Exception) {}
    }

    fun hide() {
        pointerView?.let { view ->
            try {
                windowManager.removeViewImmediate(view)
            } catch (_: Exception) {}
        }
        pointerView = null
        pointerLayoutParams = null
    }

    private class FloatingPointerView(context: Context) : View(context) {
        @Volatile var visualState: CursorVisualState = CursorVisualState.NORMAL
        @Volatile var activeGesture: GestureType = GestureType.INDEX_CURSOR
        private var clickPulseStartMs: Long = 0L

        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#3338BDF8")
        }

        private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4.5f
            color = Color.parseColor("#38BDF8")
        }

        private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#F8FAFC")
        }

        private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            color = Color.parseColor("#10B981")
        }

        fun triggerClickPulse() {
            clickPulseStartMs = System.currentTimeMillis()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f

            val radius = when (visualState) {
                CursorVisualState.NORMAL -> 20f
                CursorVisualState.HOVER -> 25f
                CursorVisualState.PINCH -> 14f
                CursorVisualState.PAUSED -> 18f
            }

            outerRingPaint.color = when (visualState) {
                CursorVisualState.PINCH -> Color.parseColor("#10B981")
                CursorVisualState.PAUSED -> Color.parseColor("#F59E0B")
                else -> Color.parseColor("#38BDF8")
            }

            canvas.drawCircle(cx, cy, radius + 4f, glowPaint)
            canvas.drawCircle(cx, cy, radius, outerRingPaint)
            canvas.drawCircle(cx, cy, 4.5f, centerDotPaint)

            val pulseElapsed = System.currentTimeMillis() - clickPulseStartMs
            if (pulseElapsed in 0..320) {
                val progress = pulseElapsed / 320f
                val pulseRadius = 16f + progress * 24f
                pulsePaint.alpha = ((1f - progress) * 255).roundToInt().coerceIn(0, 255)
                canvas.drawCircle(cx, cy, pulseRadius, pulsePaint)
                postInvalidateDelayed(16L)
            }
        }
    }

    companion object {
        private const val POINTER_WINDOW_SIZE_PX = 88
    }
}
